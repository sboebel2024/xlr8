Write-Output "Installing Proxy Server on Windows..."

# Extract the ZIP file
Expand-Archive -Path proxy_server.zip -DestinationPath proxy_server -Force

# Move into the directory
cd proxy_server

# Install dependencies
npm install

# Start the server
node server.js
