
#!/bin/bash

# Detect OS
OS=$(uname -s)

echo "Installing Proxy Server..."

# Windows (Run the PowerShell script)
if [[ "$OS" == "CYGWIN"* || "$OS" == "MINGW"* || "$OS" == "MSYS"* ]]; then
    echo "Detected Windows. Running PowerShell script..."
    powershell.exe -ExecutionPolicy Bypass -File install.ps1
    exit 0
fi

# Linux/macOS Installation
echo "Detected Linux/macOS. Proceeding with install..."

# Extract the ZIP file
unzip proxy_server.zip -d proxy_server

# Move into the directory
cd proxy_server || exit

# Install dependencies
npm install

# Start the server
node server.js
